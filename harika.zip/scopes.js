// 3 types - Global, functional, local

function abc () {
    var a = 23; // scope of the var is functional
    console.log('inside', a);
    if (a === 23) {
        let b = 2121; // block scope
        const c = 34;
        var d = 45;
    }
    
    console.log(b);
    console.log(c);
    console.log(d);
}

abc();
// console.log(a);

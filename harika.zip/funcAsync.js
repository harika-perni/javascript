console.log('1');


function acs() {
    console.log('2');
}

console.log('3');
acs();
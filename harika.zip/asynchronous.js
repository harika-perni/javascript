console.log('1');
console.log('2');
console.log('3');

setTimeout(() => { // It assigns a callback
    console.log('4');
}, 1000);
console.log('5');

setTimeout(() => {
    console.log('6');
}, 500);

console.log('7');

//V8
// eventLoop -- manages all the callbacks.

// what are callbacks in javascript
// what is callback hell
// what are promises in nodejs/javascript